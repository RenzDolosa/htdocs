/**
 * Supabase project credentials.
 *
 * The anon/public key is safe to ship to the browser — it's meant to be
 * public, the same way a Stripe publishable key or a Firebase web config
 * is. What actually gates access to your data is Row Level Security (RLS),
 * configured per-table in the Supabase dashboard, not this file.
 *
 * Never put the service_role key here, or anywhere client-side — that key
 * bypasses RLS entirely and belongs only on a trusted server.
 *
 * Fill these in from: Supabase dashboard → your project → Settings → API.
 */
export const SUPABASE_URL = 'https://YOUR-PROJECT-REF.supabase.co';
export const SUPABASE_ANON_KEY = 'YOUR-ANON-PUBLIC-KEY';
