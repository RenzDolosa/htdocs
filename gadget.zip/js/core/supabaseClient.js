import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from './supabaseConfig.js';

/**
 * Singleton Supabase client for the whole app. Import { supabase } from
 * here rather than calling createClient() again elsewhere, so every
 * feature shares one auth session and one realtime connection.
 *
 * Loaded from esm.sh rather than a local dependency — this project has no
 * package.json/bundler, everything else is plain <script type="module">
 * pointed at local files, so a CDN ES module import is the equivalent of
 * "installing" supabase-js here.
 *
 * Nothing in the app talks to Supabase yet: Gadgets, Inventory Assets,
 * Warehouses, and UserAccounts all still persist to localStorage via
 * Store.js. This is only the wired-up client, ready for whichever feature
 * migrates first.
 */
const isConfigured =
  typeof SUPABASE_URL === 'string' && SUPABASE_URL.startsWith('https://') && !SUPABASE_URL.includes('YOUR-PROJECT-REF') &&
  typeof SUPABASE_ANON_KEY === 'string' && SUPABASE_ANON_KEY.length > 0 && !SUPABASE_ANON_KEY.includes('YOUR-ANON');

export const supabase = isConfigured ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

if (!isConfigured) {
  console.warn('[supabase] Not configured yet — fill in js/core/supabaseConfig.js with your project URL and anon key.');
}
